"""Publishing module."""
from backend.publish.routes import publish_bp

__all__ = ['publish_bp']



